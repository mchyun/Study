"""
In search.py, you will implement generic search algorithms which are called
by Pacman agents (in searchAgents.py).search.py에서는 다음과 같은 일반 검색 알고리즘을 구현합니다.
Pacman 에이전트에 의해(searchAgents.py에서).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    이 클래스는 검색 문제의 구조를 설명하지만 구현하지는 않습니다.
     모든 메소드(객체 지향 용어: 추상 클래스).

     이 클래스에서 아무 것도 변경할 필요가 없습니다.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem 검색 문제의 시작 상태를 반환합니다.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state 상태: 검색 상태

        Returns True if and only if the state is a valid goal state 상태가 유효한 목표 상태인 경우에만 True를 반환합니다.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor상태: 검색 상태

         주어진 상태에 대해 이것은 트리플 목록을 반환해야 합니다.
         (successor, action, stepCost), 여기서 'successor'는
         현재 상태의 후속 작업인 'action'은 작업입니다.
         거기에 도달하는 데 필요하며 'stepCost'는 증분
         해당 후임자로 확장하는 비용
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves action: 수행할 작업 목록

         이 메서드는 특정 작업 시퀀스의 총 비용을 반환합니다. 순서는
         합법적인 움직임으로 구성
        """
        util.raiseNotDefined()

def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other
    maze, the sequence of moves will be incorrect, so only use this for tinyMaze tinyMaze를 해결하는 일련의 동작을 반환합니다. 기타
     미로, 이동 순서가 올바르지 않으므로 tinyMaze에만 사용하십시오.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s,s,w,s,w,w,s,w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first

    Your search algorithm needs to return a list of actions that reaches
    the goal.  Make sure to implement a graph search algorithm

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    검색 트리에서 가장 깊은 노드를 먼저 검색합니다.

     검색 알고리즘은 도달하는 작업 목록을 반환해야 합니다.
     목표. 그래프 검색 알고리즘을 구현해야 합니다.

     시작하려면 다음과 같은 간단한 명령을 시도해 볼 수 있습니다.
     전달되는 검색 문제를 이해합니다.

     print("시작:", 문제.getStartState())
     print("시작이 목표입니까?", problem.isGoalState(problem.getStartState()))
     print("시작의 후계자:", problem.getSuccessors(problem.getStartState()))
    """
    "*** YOUR CODE HERE ***"
    startState = problem.getStartState()
    frontier = util.Stack()
    frontier.push((startState,[]))
    went = []
    while not frontier.isEmpty():
        point, direction = frontier.pop()
        went.append(point)
        if problem.isGoalState(point):
            return direction
        for successor, action, stepcost in problem.getSuccessors(point):
            if not successor in went:
                frontier.push((successor, direction + [action]))
    return []

def breadthFirstSearch(problem):
    """
    Search the shallowest nodes in the search tree first.검색 트리에서 가장 얕은 노드를 먼저 검색합니다.
    """
    "*** YOUR CODE HERE ***"
    frontier = util.Queue()
    went = []
    frontier.push((problem.getStartState(), [], 1))
    while not frontier.isEmpty():
        point = frontier.pop()
        state = point[0]
        actions = point[1]
        if problem.isGoalState(state):
            return actions
        if state not in went:
            went.append(state)
            successor = problem.getSuccessors(state)
            for nagen in successor:
                nagen_state = nagen[0]
                nagen_action = nagen[1]
                if nagen_state not in went:
                    nagen_action = actions + [nagen_action]
                    frontier.push((nagen_state, nagen_action, 1))

def uniformCostSearch(problem):
    "Search the node of least total cost first.총 비용이 가장 적은 노드를 먼저 검색합니다. "
    "*** YOUR CODE HERE ***"
    startState = problem.getStartState()
    frontier = util.PriorityQueue()
    frontier.push((startState, [], 0), 0)
    went = dict()
    while not frontier.isEmpty():
        point, direction, cost = frontier.pop()
        went[point] = cost
        if problem.isGoalState(point):
            return direction
        for successor, action, stepcost in problem.getSuccessors(point):
            if (successor not in went) or (successor in went and went[successor] > cost + stepcost):
                went[successor] = cost + stepcost
                frontier.push((successor, direction + [action], cost + stepcost), cost + stepcost)
    return []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.휴리스틱 함수는 현재 상태에서 가장 가까운 상태까지 비용을 추정합니다.
     제공된 SearchProblem의 목표. 이 휴리스틱은 사소한 것입니다.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    "Search the node that has the lowest combined cost and heuristic first. 결합 비용과 휴리스틱이 가장 낮은 노드를 먼저 검색합니다."
    "*** YOUR CODE HERE ***"
    frontier = util.PriorityQueue()
    went = []
    frontier.push((problem.getStartState(), [], 0), heuristic(problem.getStartState(), problem))
    while not frontier.isEmpty():
        point = frontier.pop()
        state = point[0]
        actions = point[1]
        if problem.isGoalState(state):
            return actions

        if state not in went:
            went.append(state)
            successors = problem.getSuccessors(state)
            for nagen in successors:
                nagen_state = nagen[0]
                nagen_action = nagen[1]
                if nagen_state not in went:
                    nagen_action = actions + [nagen_action]
                    cost = problem.getCostOfActions(nagen_action)
                    frontier.push((nagen_state, nagen_action, 0), cost + heuristic(nagen_state, problem))

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
