from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.반사 에이전트는 검사를 통해 각 선택 지점에서 행동을 선택합니다.
       상태 평가 기능을 통한 대안.

       아래 코드는 가이드로 제공됩니다. 변경을 환영합니다
       당신이 우리의 방법을 건드리지 않는 한 당신이 적합하다고 생각하는 어떤 식 으로든
       헤더.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}이 방법을 변경할 필요는 없지만 언제든지 변경할 수 있습니다.

         getAction은 평가 기능에 따라 최상의 옵션을 선택합니다.

         이전 프로젝트와 마찬가지로 getAction은 GameState를 가져와서 반환합니다.
         {North, South, West, East, Stop} 세트의 일부 X에 대한 일부 Directions.X
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to원하는 경우 여기에 더 많은 코드를 추가하십시오."

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.여기에서 더 나은 평가 기능을 설계하십시오.

         평가 기능은 현재 및 제안된 후임자를 사용합니다.
         GameStates(pacman.py)는 숫자가 높을수록 좋은 숫자를 반환합니다.

         아래 코드는 상태에서 다음과 같은 유용한 정보를 추출합니다.
         남은 음식(newFood) 및 이동 후 Pacman 위치(newPos).
         newScaredTimes는 각 유령이 남을 이동 수를 보유합니다.
         팩맨이 파워 펠릿을 먹어서 무서워서.

         이 변수를 인쇄하여 얻은 결과를 확인한 다음 결합하십시오.
         훌륭한 평가 기능을 생성합니다.
        """
        # Useful information you can extract from a GameState (pacman.py)
        prevFood = currentGameState.getFood()
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        map = currentGameState.getWalls() #In order to obtain the height and width of the map in the current game state, information about the wall is received and stored.
        nowFood = currentGameState.getFood() #Receive and store food location information
        nowPos = currentGameState.getPacmanPosition() #Receive and store Pac-Man's location information
        largestlength = map.height-2 + map.width-2 #Add the height and width of the map because pacman and ghosts or food are the farthest from the diagonal ends of the map
        point = 0 #Declare a score of 0 to evaluate status
        if nowFood[newPos[0]][newPos[1]]:
            point += 10
        newFoodInterval = float("inf")
        for eating in newFood.asList():
            eatingInterval = manhattanDistance(newPos, eating)
            newFoodInterval = min([newFoodInterval, eatingInterval])
        newGhostInterval = float("inf")
        for enemy in successorGameState.getGhostPositions():
            ghostInterval = manhattanDistance(newPos, enemy)
            newGhostInterval = min([newGhostInterval, ghostInterval])
        if newGhostInterval < 3:
            point -= 1000
        point = point + 1.0/newFoodInterval + newGhostInterval/largestlength
        return point

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).이 기본 평가 함수는 상태의 점수만 반환합니다.
       점수는 Pacman GUI에 표시되는 것과 동일합니다.

       이 평가 기능은 적대적 검색 에이전트와 함께 사용하기 위한 것입니다.
       (반사 에이전트 아님).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.이 클래스는 모든
       다중 에이전트 검색자. 여기에 정의된 모든 방법을 사용할 수 있습니다.
       MinimaxPacmanAgent, AlphaBetaPacmanAgent 및 ExpectimaxPacmanAgent.

       여기에서 변경할 필요가 *없습니다*. 하지만 원하는 경우 변경할 수 있습니다.
       모든 적대적 검색 에이전트에 기능을 추가합니다. 하지 마십시오
       그러나 무엇이든 제거하십시오.

       참고: 이것은 추상 클래스입니다. 인스턴스화해서는 안 되는 클래스입니다. 이것의
       부분적으로만 지정되고 확장되도록 설계되었습니다. 에이전트(game.py)
       또 다른 추상 클래스입니다.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)미니맥스 에이전트(질문 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game

          gameState.isWin():
            Returns whether or not the game state is a winning state

          gameState.isLose():
            Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        def down(condition, depth, agentIndex): # A function that determines the movement of ghosts
            if depth == self.depth or condition.isWin() or condition.isLose(): #Checks whether the current depth is the same as the set depth value, and whether the current state is winning or losing the game.
                return self.evaluationFunction(condition)
            rate = float("inf")
            legalMoves = condition.getLegalActions(agentIndex)
            if agentIndex == condition.getNumAgents()-1:
                for action in legalMoves:
                    rate = min(rate, up(condition.generateSuccessor(agentIndex, action), depth+1))
            else:
                for action in legalMoves:
                    rate = min(rate, down(condition.generateSuccessor(agentIndex, action), depth, agentIndex+1))
            return rate
        def up(condition, depth): #A function that determines the movement of Pac-Man as a function to find the maximum value among the minimum values.
            if depth == self.depth or condition.isWin() or condition.isLose():
                return self.evaluationFunction(condition)
            rate = float("-inf")
            legalMoves = condition.getLegalActions()
            for action in legalMoves:
                rate = max(rate, down(condition.generateSuccessor(0, action), depth, 1))
            return rate
        shift = Directions.STOP
        rate = float("-inf")
        legalMoves = gameState.getLegalActions()
        for action in legalMoves:
            temp = down(gameState.generateSuccessor(0, action), 0, 1)
            if temp > rate:
                rate = temp
                shift = action
        return shift

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)알파-베타 가지치기가 있는 미니맥스 에이전트(질문 3)
    """
    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
          self.depth 및 self.evaluationFunction을 사용하여 최소값 작업을 반환합니다.
        """
        "*** YOUR CODE HERE ***"
        def down(force, depth, gameCondition, x, y):
            hyun = float("inf")

            followingForce = force + 1 #Calculate the next agent and increase the depth.
            if gameCondition.getNumAgents() == followingForce:
                followingForce = 0
            if followingForce == 0:
                depth += 1
            for newCondition in gameCondition.getLegalActions(force):
                hyun = min(hyun, alphabeta(followingForce, depth, gameCondition.generateSuccessor(force, newCondition), x, y))
                if hyun < x:
                    return hyun
                y = min(y, hyun)
            return hyun

        def up(force, depth, gameCondition, x, y):
            hyun = float("-inf")
            for newCondition in gameCondition.getLegalActions(force):
                hyun = max(hyun, alphabeta(1, depth, gameCondition.generateSuccessor(force, newCondition), x, y))
                if hyun > y:
                    return hyun
                x = max(x, hyun)
            return hyun

        def alphabeta(force, depth, gameCondition, x, y):
            if gameCondition.isLose() or gameCondition.isWin() or depth == self.depth: #Returns when depth is reached or the game wins or loses.
                return self.evaluationFunction(gameCondition)
            if force == 0:
                return up(force, depth, gameCondition, x, y)
            else:
                return down(force, depth, gameCondition, x, y)

        use = float("-inf")
        action = Directions.WEST
        myung = float("-inf")
        chul = float("inf")
        for agentState in gameState.getLegalActions(0):
            ghostValue = alphabeta(1, 0, gameState.generateSuccessor(0, agentState), myung, chul)
            if ghostValue > use:
                use = ghostValue
                action = agentState
            if use > chul:
                return use
            myung = max(myung, use)
        return action

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)귀하의 expectimax 에이전트(질문 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
          self.depth 및 self.evaluationFunction을 사용하여 Expectimax 작업을 반환합니다.

           모든 유령은 무작위로 균일하게 선택하는 것으로 모델링되어야 합니다.
           법적 조치.
        """
        "*** YOUR CODE HERE ***"
        def expect(condition, depth, agentIndex): # A function that determines the movement of ghosts
            if depth == self.depth or condition.isWin() or condition.isLose():
                return self.evaluationFunction(condition)
            rate = 0
            legalMoves = condition.getLegalActions(agentIndex)
            if agentIndex == condition.getNumAgents()-1:
                for action in legalMoves:
                    rate += up(condition.generateSuccessor(agentIndex, action), depth+1)
            else:
                for action in legalMoves:
                    rate += expect(condition.generateSuccessor(agentIndex, action), depth, agentIndex+1)
            return rate/len(legalMoves)

        def up(condition, depth): # A function that finds the largest value among the estimates
            if depth == self.depth or condition.isWin() or condition.isLose(): #Check whether the current depth is the same as the set depth value, and whether the current state is winning or losing the game.
                return self.evaluationFunction(condition)
            rate = float("-inf")
            legalMoves = condition.getLegalActions()
            for action in legalMoves:
                rate = max(rate, expect(condition.generateSuccessor(0, action), depth, 1))
            return rate

        legalMoves = gameState.getLegalActions() #Stores the possible moves in the current game state as a list.
        shift = Directions.STOP
        rate = float("-inf")
        for action in legalMoves:
            dong = expect(gameState.generateSuccessor(0, action), 0, 1)
            if dong > rate:
                rate = dong
                shift = action
        return shift

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
      당신의 극단적인 유령 사냥, 펠릿 잡아먹기, 음식 섭식, 멈출 수 없는
       평가 기능(질문 5).

       설명: <당신이 한 일을 알 수 있도록 여기에 글을 쓰세요>
    """
    "*** YOUR CODE HERE ***"
    capPos = currentGameState.getCapsules()
    nowPos = currentGameState.getPacmanPosition()
    nowFood = currentGameState.getFood()
    map = currentGameState.getWalls()
    largestlength = map.height-2 + map.width-2
    capInterval = [] # Declare a list to store the distances between the capsule item and Pac-Man.
    eatingInterval = [] # Declare a list to store distances between food and Pac-Man
    for cap in capPos:
        capInterval.append(manhattanDistance(nowPos, cap))
    for eating in nowFood.asList():
        eatingInterval.append(manhattanDistance(nowPos, eating))
    point = 0
    hyun = nowPos[0]
    myung = nowPos[1]
    for ghostState in currentGameState.getGhostStates(): #Loop through all ghosts
        chul = manhattanDistance(nowPos, ghostState.configuration.getPosition())
        if chul <2:
            if ghostState.scaredTimer != 0:
                point += 2000.0/(chul+1)
            else:
                point -= 2000.0/(chul+1)
    if min(capInterval+[float(100)]) < 5:
        point += 1000.0/(min(capInterval))
    for cap in capPos:
        if (cap[0] == hyun)&(cap[1] == myung):
            point += 1200.0
    mineatinginterval = min(eatingInterval+[float(100)])
    return point + 1.0/mineatinginterval - len(eatingInterval)*10.0



# Abbreviation
better = betterEvaluationFunction
