STUDENT_CODE_DEFAULT = 'addition.py,average.py,buyLotsOfFruit.py,shopSmart.py,shopSmart.py,shopSmart.py'
PROJECT_TEST_CLASSES = 'tutorialTestClasses.py'
PROJECT_NAME = 'Assignment 0'
